/*
 * switch.h
 *
 *  Created on: Apr 17, 2022
 *      Author: pwmag
 */

#ifndef SWITCH_H_
#define SWITCH_H_

#include <Arduino.h>
#include <Keyboard.h>

#include "defines.h"

void sw_init();

#endif /* SWITCH_H_ */

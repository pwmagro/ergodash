/*
 * defines.h
 *
 *  Created on: Apr 15, 2022
 *      Author: pwmag
 */

#ifndef DEFINES_H_
#define DEFINES_H_

#include "config.h"

#ifdef V1_0
	#define SW0			7u
	#define SW1			5u		// Unusable!
	#define SW2			28u
	#define SW3			29u
	#define SW4			2u
	#define SW5			10u
	#define SW6			9u

	#define EN_A		12u
	#define EN_B		13u
	#define SW7			11u		// Broken... maybe?

	#define LED_LPINS	{27u, 26u, 30u}
	#define LED_HPINS	{A1, A2, A3}

	#define NUM_LEDS	9u
	#define LED_HN		3u
	#define LED_LN		3u

#elif defined V1_1
	#define SW0			12u
	#define SW1			10u
	#define SW2			A5
	#define SW3			A4
	#define SW4			26u
	#define SW5			9u
	#define SW6			A3

	#define EN_A		1u
	#define EN_B		A1
	#define SW7			0u

	#define LED_LPINS	{27u, 12u, 11u}
	#define LED_HPINS	{7u, 2u, 30u}

	#define NUM_LEDS	9u
	#define LED_HN		3u
	#define LED_LN		3u

#endif

#define DOTSTAR_DAT	41u
#define DOTSTAR_CLK	40u

#endif /* DEFINES_H_ */

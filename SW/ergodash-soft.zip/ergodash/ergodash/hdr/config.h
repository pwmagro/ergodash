/*
 * config.h
 *
 *  Created on: Apr 15, 2022
 *      Author: pwmag
 */

#ifndef CONFIG_H_
#define CONFIG_H_

// Version definition
#define V1_0
#define DEBUG		1
#define WAIT_FOR_SERIAL

#endif /* CONFIG_H_ */

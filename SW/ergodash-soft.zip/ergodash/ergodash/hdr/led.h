/*
 * led.h
 *
 *  Created on: Apr 15, 2022
 *      Author: pwmag
 */

#ifndef LED_H_
#define LED_H_

#define TRISTATE(x)		pinMode(x, INPUT)

#include "Arduino.h"
#include "arduino-timer.h"
#include "defines.h"

void led_init();
void led_singleWrite(uint32_t led, bool val);
void led_multiWrite(bool *values);
bool led_multiplex(void *temp);
bool spread_leds();
bool blink();

#endif /* LED_H_ */

/*
 * dotstar.h
 *
 *  Created on: Apr 17, 2022
 *      Author: pwmag
 */

#ifndef DOTSTAR_H_
#define DOTSTAR_H_

#include <APA102.h>
#include <Arduino.h>
#include "defines.h"

#define DS_CNT		1

void dotstar_kill();


#endif /* DOTSTAR_H_ */

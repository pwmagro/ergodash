/*
 * fat.h
 *
 *  Created on: Apr 27, 2022
 *      Author: pwmag
 */

#ifndef ERGODASH_HDR_FAT_H_
#define ERGODASH_HDR_FAT_H_

#include <Arduino.h>
#include <SPI.h>
#include <SdFat.h>
#include <Adafruit_SPIFlash.h>
#include <ArduinoJson.h>

#define ROOT_PATH	"/ergodash"
#define CONFIG_PATH "/ergodash/config"
#define CONFIG_FILE "/ergodash/config/config.txt"

#define DEFAULT_CONFIG "{\"version\": \"1.1.1\",\"configs\":[{\"SW0\": \"a\",\"SW1\": \"s\",\"SW2\": \"s\",\"SW3\": \"s\",\"SW4\": 216,\"SW5\": 215,\"LED_MODE\": \"Static\"}]}"

static DynamicJsonDocument fat_configJson(2048);

void fat_init();

#endif /* ERGODASH_HDR_FAT_H_ */

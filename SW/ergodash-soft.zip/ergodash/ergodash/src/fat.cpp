/*
 * fat.cpp
 *
 *  Created on: Apr 27, 2022
 *      Author: pwmag
 */

#include "fat.h"

static Adafruit_FlashTransport_SPI flashTransport(EXTERNAL_FLASH_USE_CS, EXTERNAL_FLASH_USE_SPI);
static Adafruit_SPIFlash flash(&flashTransport);
static FatFileSystem fatfs;
static File configFile;


bool fat_format();
void fat_resetConfig();
void fat_refreshConfig();


void fat_init() {

	Serial.println("\n\n--\tSPI Flash FAT initializing...\t--");

	if (!flash.begin()) {
		Serial.println("Failed to initialize flash chip!");
		while(1) yield();
	}
	Serial.print("Flash chip JEDEC ID: 0x");
	Serial.println(flash.getJEDECID(), HEX);

	if (!fatfs.begin(&flash)) {
		Serial.println("Failed to mount filesystem.");
		Serial.println("Attempting to format...");

		if (!fat_format()) {
			Serial.println("Failed to format flash chip!");
			while(1) yield();
		}
	}
	Serial.println("Mounted filesystem.");

	Serial.println("\nLoading config...");
	if (!fatfs.exists(CONFIG_PATH)) {
		Serial.println("Config path does not exist. Attempting to create directory...");
		fatfs.mkdir(CONFIG_PATH);

		if (!fatfs.exists(CONFIG_PATH)) {
			Serial.println("Failed to create config directory.");
			while(1) yield();
		}
		else {
			Serial.println("Created config directory");
		}
	}

	if (!fatfs.exists(CONFIG_FILE)) {
		Serial.println("Config file not found. Writing default file...");
		fat_resetConfig();
	}

	if (fatfs.exists(CONFIG_FILE)) {
		fat_refreshConfig();
	}
	else {
		Serial.println("Failed to create config file!");
		while(1) yield();
	}
}

// May implement later, but for now, I want to keep things separate
bool fat_format() {
	return false;
}

void fat_resetConfig() {
	if (fatfs.exists(CONFIG_FILE)) {
		Serial.println("Default config already exists - deleting.");
		fatfs.remove(CONFIG_FILE);
	}

	configFile = fatfs.open(CONFIG_FILE, FILE_WRITE);

	//TODO actually implement DEFAULT_CONFIG
	configFile.write(DEFAULT_CONFIG);

	configFile.close();
	Serial.println("Rewrote default config!");
}

void fat_refreshConfig() {
	configFile = fatfs.open(CONFIG_FILE, FILE_READ);

	String configRaw;
	while(configFile.available()) {
		if(configFile.available() >= 2048) {
			Serial.println("Config file too large!");
			while(1) yield();
		}

		configRaw.concat((char)configFile.read());
	}

	configFile.close();

	Serial.println("Config file read:");
	Serial.println(configRaw);

	if (deserializeJson(fat_configJson, configRaw) != DeserializationError::Ok) {
		Serial.println("Config was invalid! Resetting to default...");
		fat_resetConfig();
	}

}

/*
 * switch.cpp
 *
 *  Created on: Apr 17, 2022
 *      Author: pwmag
 */

#include "switch.h"
void sw0_event();
void sw1_event();
void sw2_event();
void sw3_event();
void sw4_event();
void sw5_event();
void sw6_event();

void sw_init() {

	Serial.println("\n\n--\tSwitch interrupts initializing...\t--");

	Serial.println("Opening keyboard...");
	Keyboard.begin();

	Serial.println("Attaching interrupts...");
	pinMode(SW0, INPUT);
	attachInterrupt(digitalPinToInterrupt(SW0), sw0_event, CHANGE);

	pinMode(SW2, INPUT);
	attachInterrupt(digitalPinToInterrupt(SW2), sw2_event, CHANGE);

	pinMode(SW3, INPUT);
	attachInterrupt(digitalPinToInterrupt(SW3), sw3_event, CHANGE);

	pinMode(SW4, INPUT);
	attachInterrupt(digitalPinToInterrupt(SW4), sw4_event, CHANGE);

	pinMode(SW5, INPUT);
	attachInterrupt(digitalPinToInterrupt(SW5), sw5_event, CHANGE);

	pinMode(SW6, INPUT);
	attachInterrupt(digitalPinToInterrupt(SW6), sw6_event, CHANGE);

	KEY_LEFT_ARROW;

#ifndef V1_0
	pinMode(SW1, INPUT);
	attachInterrupt(digitalPinToInterrupt(SW1), sw1_event, CHANGE);
#endif
}

void sw0_event() {
	if (!digitalRead(SW0)) {
		Serial.println("SW0");
#ifdef KEYBOARD_EN
		Keyboard.press('a');
#endif
	}
	else {
#ifdef KEYBOARD_EN
		Keyboard.release('a');
#endif
	}
}

void sw1_event() {
	if (!digitalRead(SW1)) {
		Serial.println("SW1");
#ifdef KEYBOARD_EN
		Keyboard.press('s');
#endif
	}
	else {
#ifdef KEYBOARD_EN
		Keyboard.release('s');
#endif
	}
}

void sw2_event() {
	if (!digitalRead(SW2)) {
		Serial.println("SW2");
#ifdef KEYBOARD_EN
		Keyboard.press('j');
#endif
	}
	else {
#ifdef KEYBOARD_EN
		Keyboard.release('j');
#endif
	}
}

void sw3_event() {
	if (!digitalRead(SW3)) {
		Serial.println("SW3");
#ifdef KEYBOARD_EN
		Keyboard.press('k');
#endif
	}
	else {
#ifdef KEYBOARD_EN
		Keyboard.release('k');
#endif
	}
}

void sw4_event() {
	if (!digitalRead(SW4)) {
		Serial.println("SW4");
#ifdef KEYBOARD_EN
		Keyboard.press(' ');
#endif
	}
	else {
#ifdef KEYBOARD_EN
		Keyboard.release(' ');
#endif
	}
}

void sw5_event() {
	if (!digitalRead(SW5)) {
		Serial.println("SW5");
#ifdef KEYBOARD_EN
		Keyboard.press('s');
#endif
	}
	else {
#ifdef KEYBOARD_EN
		Keyboard.release('s');
#endif
	}
}

void sw6_event() {
	if (!digitalRead(SW6)) {
		Serial.println("SW6");
#ifdef KEYBOARD_EN
		Keyboard.press('j');
#endif
	}
	else {
#ifdef KEYBOARD_EN
		Keyboard.release('j');
#endif
	}
}

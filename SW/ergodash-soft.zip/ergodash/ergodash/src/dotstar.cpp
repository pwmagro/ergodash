/*
 * dotstar.cpp
 *
 *  Created on: Apr 17, 2022
 *      Author: pwmag
 */
#include "dotstar.h"

void dotstar_kill() {
	Serial.println("\n\n--\tKilling DotStar LED...\t--");
	Serial.println("God, it's so bright");

	// No idea why this is necessary
	Serial.read();


	APA102<DOTSTAR_DAT, DOTSTAR_CLK> led;
	rgb_color colors[1];

	colors[0] = rgb_color(0, 0, 0);

	led.write(colors, DS_CNT, 0);
}

#include "led.h"

static bool led_values[NUM_LEDS];
static uint32_t hpins[] = LED_HPINS;
static uint32_t lpins[] = LED_LPINS;

void led_init() {
	Serial.println("\n\n--\tLED driver initializing...\t--");
	Serial.printf("Using %d LEDs in a %dx%d configuration.\n", NUM_LEDS, LED_LN, LED_HN);

#if (not defined V1_0) and (not defined V1_1)
	pinMode(13, OUTPUT);
#endif

	for (int i = 0; i < NUM_LEDS; i++) {
		led_values[i] = LOW;
	}

	for (int n = 0; n < LED_LN; n++) {
		TRISTATE(lpins[n]);
	}

	for (int n = 0; n < LED_HN; n++) {
		TRISTATE(hpins[n]);
	}
}

void led_singleWrite(uint32_t led, bool val) {
	led_values[led] = val;
}

void led_multiWrite(bool *values) {
	for (int i = 0; i < NUM_LEDS; i++) {
		led_values[i] = values[i];
	}
}

bool led_multiplex(void *temp) {

	for (int i = 0; i < NUM_LEDS; i++) {

		uint32_t lpin = lpins[i % LED_HN];
		uint32_t hpin = hpins[i / LED_HN];

		pinMode(lpin, OUTPUT);
		pinMode(hpin, OUTPUT);

		digitalWrite(lpin, LOW);
		digitalWrite(hpin, led_values[i]);

			delay(1);

		TRISTATE(lpin);
		digitalWrite(hpin, 0);

	}
	return true;
}


// mostly for debugging
bool spread_leds() {
	static bool leds[NUM_LEDS];
	static uint32_t count = 0;

	led_multiWrite(leds);
	leds[count] = !leds[count];

	count = ++count % NUM_LEDS;
	return true;
}

bool blink() {
	static volatile bool redled = false;

	redled = !redled;
	digitalWrite(13, redled);
	return true;
}

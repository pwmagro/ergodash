#ifdef __IN_ECLIPSE__
//This is a automatic generated file
//Please do not modify this file
//If you touch this file your change will be overwritten during the next build
//This file has been generated on 2022-04-27 19:49:16

#include "Arduino.h"
#include "Arduino.h"
#include <arduino-timer.h>
#include "config.h"
#include "defines.h"
#include "led.h"
#include "dotstar.h"
#include "switch.h"
#include "fat.h"

void setup() ;
void loop() ;

#include "ergodash.ino"


#endif
